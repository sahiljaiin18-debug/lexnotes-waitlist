import nodemailer from 'nodemailer';

const SUPABASE_URL = 'https://wsayghqewyqvybzflqew.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndzYXlnaHFld3lxdnliemZscWV3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg3NDgxNzAsImV4cCI6MjA5NDMyNDE3MH0.29_PNiKVVY2516F1p8lE0N_fFY80s4m-97mDZBXs21E';
const EMAIL_USER = 'info.lexnotes@gmail.com';

function clean(value = '') {
  return String(value).trim();
}

function escapeHtml(value = '') {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

async function saveToSupabase(entry) {
  const payload = {
    intent: entry.intent,
    name: entry.name,
    email: entry.email,
    college: entry.college || null,
    year_sem: entry.year || null,
    confirmation_email_sent: false,
    launch_email_sent: false
  };

  const response = await fetch(`${SUPABASE_URL}/rest/v1/waitlist_signups?on_conflict=email`, {
    method: 'POST',
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
      Prefer: 'resolution=merge-duplicates,return=representation'
    },
    body: JSON.stringify(payload)
  });

  const text = await response.text();
  if (!response.ok) {
    let message = 'Could not save signup.';
    try {
      const parsed = JSON.parse(text);
      message = parsed.message || parsed.error || message;
    } catch (_) {}
    throw new Error(message);
  }

  try {
    return JSON.parse(text)?.[0] || null;
  } catch (_) {
    return null;
  }
}

async function markEmailSent(email) {
  await fetch(`${SUPABASE_URL}/rest/v1/waitlist_signups?email=eq.${encodeURIComponent(email)}`, {
    method: 'PATCH',
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ confirmation_email_sent: true })
  });
}

async function sendConfirmation(entry) {
  if (!process.env.EMAIL_APP_PASSWORD) {
    return false;
  }

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: EMAIL_USER,
      pass: process.env.EMAIL_APP_PASSWORD
    }
  });

  const safeName = escapeHtml(entry.name);
  const sellerLine = entry.intent === 'seller'
    ? 'We’ll review contributor submissions for clarity, usefulness, and academic relevance before anything goes live.'
    : 'You’ll be notified when early access opens for curated notes.';

  await transporter.sendMail({
    from: `LexNotes <${EMAIL_USER}>`,
    to: entry.email,
    subject: 'You’re on the LexNotes early access list',
    text: `Hi ${entry.name},\n\nYou’re on the LexNotes early access list.\n\n${sellerLine}\n\nWe’re building carefully and will share launch updates soon.\n\n— LexNotes`,
    html: `
      <div style="margin:0;padding:28px;background:#f6f0e6;color:#191613;font-family:Georgia,'Times New Roman',serif;line-height:1.65;">
        <div style="max-width:560px;margin:0 auto;background:#fffaf2;border:1px solid #d8cbb8;border-radius:22px;padding:28px;">
          <p style="font-size:14px;letter-spacing:.12em;text-transform:uppercase;color:#766b5d;margin:0 0 18px;">LexNotes early access</p>
          <h1 style="font-size:28px;line-height:1.2;margin:0 0 18px;font-weight:400;">You’re on the list.</h1>
          <p>Hi ${safeName},</p>
          <p>Thanks for joining the LexNotes early-access waitlist.</p>
          <p>${sellerLine}</p>
          <p>We’re building carefully and will share launch updates soon.</p>
          <p style="margin-top:28px;">— LexNotes</p>
        </div>
      </div>
    `
  });

  return true;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const entry = {
    name: clean(req.body?.name),
    email: clean(req.body?.email).toLowerCase(),
    college: clean(req.body?.college),
    year: clean(req.body?.year),
    intent: clean(req.body?.intent) === 'seller' ? 'seller' : 'buyer'
  };

  if (!entry.name || !entry.email || !/^\S+@\S+\.\S+$/.test(entry.email)) {
    return res.status(400).json({ error: 'Please enter a valid name and email.' });
  }

  try {
    await saveToSupabase(entry);
    const emailSent = await sendConfirmation(entry);
    if (emailSent) await markEmailSent(entry.email);

    return res.status(200).json({
      ok: true,
      emailSent,
      message: emailSent
        ? 'You’re on the list. Check your inbox for confirmation.'
        : 'You’re on the list. Email confirmation will be enabled after SMTP is configured.'
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: error.message || 'Could not save signup.' });
  }
}
