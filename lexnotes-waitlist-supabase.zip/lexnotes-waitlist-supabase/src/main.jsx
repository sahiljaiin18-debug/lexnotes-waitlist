import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

function App() {
  const [intent, setIntent] = useState('buyer');
  const [form, setForm] = useState({ name: '', email: '', college: '', year: '' });
  const [status, setStatus] = useState('idle');
  const [message, setMessage] = useState('');

  const update = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setStatus('loading');
    setMessage('');

    try {
      const res = await fetch('/api/waitlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, year_sem: form.year, intent })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Signup failed');

      setStatus('success');
      setMessage(data.message || 'You’re on the list. Check your inbox for confirmation.');
      setForm({ name: '', email: '', college: '', year: '' });
    } catch (err) {
      setStatus('error');
      setMessage(err.message || 'Something went wrong. Please try again.');
    }
  };

  return (
    <main className="page">
      <header className="nav">
        <a className="brand" href="https://lexnotes-seven.vercel.app" aria-label="LexNotes home"><span className="brand-mark">L</span><span>LexNotes</span></a>
        <span className="nav-note">Early access</span>
      </header>

      <section className="hero">
        <p className="eyebrow">Curated legal study material</p>
        <h1>Law notes, rethought.</h1>
        <p className="subhead">
          LexNotes is opening early access for law students who want clearer notes, cleaner revision, and a more reliable way to share useful study material.
        </p>
      </section>

      <section className="signup-panel" aria-label="Join the waitlist">
        <div className="choice-grid">
          <button className={`choice ${intent === 'buyer' ? 'active' : ''}`} onClick={() => setIntent('buyer')} type="button">
            <span>I want notes</span>
            <small>Get notified when curated subject notes go live.</small>
          </button>
          <button className={`choice ${intent === 'seller' ? 'active' : ''}`} onClick={() => setIntent('seller')} type="button">
            <span>I want to sell notes</span>
            <small>Apply to become an early contributor.</small>
          </button>
        </div>

        {intent === 'seller' && (
          <div className="seller-note">
            Every submission is reviewed for clarity, usefulness, and academic relevance before publication.
          </div>
        )}

        <form onSubmit={submit} className="form">
          <label>
            Name
            <input name="name" value={form.name} onChange={update} required placeholder="Your name" />
          </label>
          <label>
            Email
            <input name="email" type="email" value={form.email} onChange={update} required placeholder="you@example.com" />
          </label>
          <div className="two-col">
            <label>
              College <span>optional</span>
              <input name="college" value={form.college} onChange={update} placeholder="Law college" />
            </label>
            <label>
              Year/Sem <span>optional</span>
              <input name="year" value={form.year} onChange={update} placeholder="e.g. 3rd year" />
            </label>
          </div>
          <button className="submit" disabled={status === 'loading'} type="submit">
            {status === 'loading' ? 'Joining…' : intent === 'seller' ? 'Join as contributor' : 'Join waitlist'}
          </button>
          {message && <p className={`status ${status}`}>{message}</p>}
        </form>
      </section>

      <section className="closing">
        <p>Built carefully for law students who care about clarity.</p>
      </section>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
